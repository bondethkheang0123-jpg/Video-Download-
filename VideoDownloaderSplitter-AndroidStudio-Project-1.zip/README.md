# Video Toolkit — Android starter project

Dark-mode Android app starter for:
- Downloading a direct HTTP(S) video URL using Android DownloadManager.
- Selecting a local video with Android's document picker.
- Splitting supported local media into numbered MP4 parts.
- Custom part duration in minutes.
- Preserving the original source.

## Important limitations
- This starter does **not** download videos from YouTube pages. YouTube's official API does not provide a general-purpose media download endpoint. Use YouTube's official offline/download options where available, or import a file you own and are authorized to use. Do not bypass access controls, DRM, or platform restrictions.
- Direct URL downloads only work when the URL points to a downloadable media file and the host permits it. Some servers may reject Android DownloadManager requests or require authentication.
- Android's native MediaExtractor/MediaMuxer support varies by device and codec. Output cuts align to encoded sample/keyframe boundaries and may not be exact to the millisecond. Some input containers/codecs may fail.
- This is a source project, not a prebuilt APK. Build it with Android Studio on a computer with Android SDK installed.

## Build APK
1. Install current Android Studio and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Select **Build > Build APK(s)**.
5. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- Output files are written to the app-specific Movies directory, usually:
  `Android/data/com.example.videodownsplit/files/Movies/VideoToolkit/`
- Downloads are saved in the public Downloads folder via DownloadManager (filename: `VideoToolkit_downloaded_video.mp4`).
- The download button starts an OS-managed download; its progress is shown in Android notifications. Split progress is shown in the app.
- This starter is intended as a foundation and should be tested with representative files before daily use.

## Phone-only cloud build (GitHub Actions)
This project includes `.github/workflows/build-apk.yml`.
1. On your phone, create a GitHub account or sign in at https://github.com.
2. Create a new repository.
3. Upload the extracted project files, including the hidden `.github/workflows/build-apk.yml` path. GitHub's web upload can be awkward for folders; using the GitHub mobile app/browser or a ZIP-to-repository upload tool may be necessary.
4. Open the repository's **Actions** tab and run **Build Android APK** (or push to `main`).
5. When the run succeeds, open the workflow run and download the `VideoToolkit-debug-apk` artifact. Extract the artifact ZIP to get `app-debug.apk`.
6. Tap the APK on your phone to install it, allowing installation from that browser/files app if Android asks.

The workflow has been included but has not been run from this environment; it does not mean an APK has already been built.
