package com.example.videodownsplit

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer

/**
 * Splits MP4-compatible audio/video tracks without re-encoding. Cut points are approximate
 * because video cuts align to encoded sample/keyframe boundaries. Original source is untouched.
 */
object VideoSplitter {
    fun split(
        context: Context,
        uri: Uri,
        outputDir: File,
        baseName: String,
        partDurationMs: Long,
        onProgress: (Int, Int) -> Unit
    ): Int {
        val probe = MediaExtractor()
        probe.setDataSource(context, uri, null)
        val trackCount = probe.trackCount
        var durationUs = 0L
        for (i in 0 until trackCount) {
            val f = probe.getTrackFormat(i)
            if (f.containsKey(MediaFormat.KEY_DURATION)) durationUs = maxOf(durationUs, f.getLong(MediaFormat.KEY_DURATION))
        }
        probe.release()
        if (durationUs <= 0L) throw IllegalArgumentException("Could not read video duration")
        val segmentUs = partDurationMs * 1000L
        val total = ((durationUs + segmentUs - 1) / segmentUs).toInt().coerceAtLeast(1)

        for (partIndex in 0 until total) {
            val startUs = partIndex * segmentUs
            val endUs = minOf(durationUs, startUs + segmentUs)
            val extractor = MediaExtractor()
            extractor.setDataSource(context, uri, null)
            val muxerFile = File(outputDir, "${baseName}_Part_${(partIndex + 1).toString().padStart(2, '0')}.mp4")
            var muxer: MediaMuxer? = null
            try {
                muxer = MediaMuxer(muxerFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                val trackMap = HashMap<Int, Int>()
                for (track in 0 until extractor.trackCount) {
                    val format = extractor.getTrackFormat(track)
                    val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                        trackMap[track] = muxer.addTrack(format)
                        extractor.selectTrack(track)
                    }
                }
                if (trackMap.isEmpty()) throw IllegalArgumentException("No supported audio/video tracks")
                muxer.start()
                val bufferSize = 2 * 1024 * 1024
                val buffer = ByteBuffer.allocate(bufferSize)
                val info = MediaCodec.BufferInfo()
                for ((sourceTrack, _) in trackMap) extractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                var firstSample = true
                while (true) {
                    val sourceTrack = extractor.sampleTrackIndex
                    if (sourceTrack < 0) break
                    val sampleTime = extractor.sampleTime
                    if (sampleTime >= endUs) break
                    if (sampleTime >= startUs && trackMap.containsKey(sourceTrack)) {
                        buffer.clear()
                        val size = extractor.readSampleData(buffer, 0)
                        if (size < 0) break
                        info.offset = 0
                        info.size = size
                        info.presentationTimeUs = sampleTime - startUs
                        info.flags = extractor.sampleFlags
                        muxer.writeSampleData(trackMap[sourceTrack]!!, buffer, info)
                        firstSample = false
                    }
                    if (!extractor.advance()) break
                }
                if (firstSample) throw IllegalArgumentException("No samples found for part ${partIndex + 1}")
            } catch (e: Exception) {
                muxerFile.delete()
                throw e
            } finally {
                try { muxer?.stop() } catch (_: Exception) {}
                try { muxer?.release() } catch (_: Exception) {}
                extractor.release()
            }
            onProgress(partIndex + 1, total)
        }
        return total
    }
}
