package com.example.videodownsplit

import androidx.activity.ComponentActivity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private var selectedUri: Uri? = null
    private lateinit var status: TextView
    private lateinit var selectedLabel: TextView
    private lateinit var progress: ProgressBar
    private lateinit var downloadButton: Button
    private lateinit var splitButton: Button

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedUri = uri
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            selectedLabel.text = displayName(uri)
            status.text = "Video selected"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.statusLabel)
        selectedLabel = findViewById(R.id.selectedLabel)
        progress = findViewById(R.id.progress)
        downloadButton = findViewById(R.id.downloadButton)
        splitButton = findViewById(R.id.splitButton)

        findViewById<Button>(R.id.chooseButton).setOnClickListener {
            pickVideo.launch(arrayOf("video/*"))
        }
        downloadButton.setOnClickListener { startDownload() }
        splitButton.setOnClickListener { splitSelectedVideo() }
    }

    private fun startDownload() {
        val raw = findViewById<EditText>(R.id.urlInput).text.toString().trim()
        val uri = try { Uri.parse(raw) } catch (_: Exception) { null }
        if (uri == null || (uri.scheme != "https" && uri.scheme != "http") || uri.host.isNullOrBlank()) {
            status.text = "Enter a valid direct HTTP(S) video URL."
            return
        }
        if (uri.path.orEmpty().endsWith(".m3u8", true) || uri.path.orEmpty().endsWith(".mpd", true)) {
            status.text = "Streaming playlists are not supported by this starter app."
            return
        }
        try {
            val request = DownloadManager.Request(uri)
                .setTitle("Video Toolkit download")
                .setDescription("Downloading an authorized video")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "VideoToolkit_downloaded_video.mp4")
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            status.text = "Download queued. Android will show download progress in notifications."
            Toast.makeText(this, "Download started", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            status.text = "Could not start download: ${e.localizedMessage ?: "unknown error"}"
        }
    }

    private fun splitSelectedVideo() {
        val uri = selectedUri
        if (uri == null) {
            status.text = "Choose a local video first. Downloaded files can be selected from Movies."
            return
        }
        val minutes = findViewById<EditText>(R.id.minutesInput).text.toString().toLongOrNull()
        if (minutes == null || minutes < 1 || minutes > 1440) {
            status.text = "Enter a part length from 1 to 1440 minutes."
            return
        }
        setBusy(true)
        status.text = "Preparing video…"
        executor.execute {
            try {
                val outDir = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "VideoToolkit")
                if (!outDir.exists()) outDir.mkdirs()
                val baseName = displayName(uri).substringBeforeLast('.', "video")
                    .replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "video" }
                val count = VideoSplitter.split(this, uri, outDir, baseName, minutes * 60_000L) { done, total ->
                    runOnUiThread {
                        progress.visibility = View.VISIBLE
                        progress.max = total.coerceAtLeast(1)
                        progress.progress = done
                        status.text = "Splitting… $done / $total parts"
                    }
                }
                runOnUiThread {
                    setBusy(false)
                    progress.visibility = View.GONE
                    status.text = "Finished: created $count part(s) in app Movies/VideoToolkit."
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setBusy(false)
                    progress.visibility = View.GONE
                    status.text = "Split failed: ${e.localizedMessage ?: "unsupported or damaged video"}"
                }
            }
        }
    }

    private fun setBusy(busy: Boolean) {
        downloadButton.isEnabled = !busy
        splitButton.isEnabled = !busy
        findViewById<Button>(R.id.chooseButton).isEnabled = !busy
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        if (!busy) progress.progress = 0
    }

    private fun displayName(uri: Uri): String {
        var name = "video"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) name = c.getString(0) ?: name
        }
        return name
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
